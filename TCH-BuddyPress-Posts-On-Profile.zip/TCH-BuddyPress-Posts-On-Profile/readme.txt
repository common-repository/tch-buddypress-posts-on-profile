=== TCH BuddyPress Posts on Profiles ===
Contributors: azchipka
Donate Link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=P3V9FC6W7KRPA
Tags: buddypress, profile, posts, show posts on profile, bp, extend profile 
Requires at least: WordPress 3.5, BuddyPress 1.7
Tested up to: WordPress 3.6 / BuddyPress 1.7
Stable tag: 1.0
License: GPLv2 or later


Adds a tab for user profile posts on buddypress profiles.

== Description ==
TCH BuddyPress Posts On Profile does exactly what it sounds like. It adds a new tab
to the profiles of your BuddyPress users that displays the posts they have made on the
blog. 

== Installation ==

Upload the plugin and activate and your done!

== Screenshots ==

1. Shows display of "My Posts" tab in the Buddy Press Profile
2. Error Message for user with no published posts

== Frequently Asked Questions ==

= Does this plugin work for multi-site / network installations =
This plugin has only been tested on stand alone installations.

= I see the tab for "My Posts" but all that is in it is a message that says "Sorry, this user has not published any posts." =
That means the user doesn't have any published posts. Tell them to get writting!

== Changelog ==

= 0.1 =
* Initial Release *
