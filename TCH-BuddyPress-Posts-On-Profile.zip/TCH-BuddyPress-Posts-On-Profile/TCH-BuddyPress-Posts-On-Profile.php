<?php
/*
Plugin Name: TCH BP Posts On Profile
Plugin URI: http://azchipka.thechipkahouse.com/services/technology/development/wordpress-plugins
Description: Adds a tab to Buddy Press User Profile displaying the posts they have published. 
Version: 0.1
Author: Avery Z Chipka
Author URI: http://azchipka.thechipkahouse.com
License: GPLv2 or later
*/
// Make sure we don't expose any info if called directly

if ( !function_exists( 'add_action' ) ) {
	echo 'Hi there!  I\'m just a plugin, not much I can do when called directly.';
	exit;
}
define('TCH_PostsOnProfilesVersion', '0.1');
define('TCH_PostsOnProfilesVersion_PLUGIN_URL', plugin_dir_url( __FILE__ ));

add_action( 'bp_setup_nav', 'add_profileposts_tab', 100 );
function add_profileposts_tab() {
global $bp;
bp_core_new_nav_item( array(
'name' => 'My Posts',
'slug' => 'posts',
'screen_function' => 'bp_postsonprofile',
'default_subnav_slug' => 'My Posts', 
'position' => 25
)
);
// show feedback when 'Posts' tab is clicked
function bp_postsonprofile() {
add_action( 'bp_template_content', 'profile_screen_posts_show' );
bp_core_load_template( apply_filters( 'bp_core_template_plugin', 'members/single/plugins' ) );
}

function profile_screen_posts_show() {
$theuser = bp_displayed_user_id(); 
query_posts("author=$theuser" );
if ( have_posts() ) :
get_template_part( 'loop', 'archive' );
else: ?>
<div id="message" class="info">
		<p><?php _e( 'Sorry, this user has not published any posts.', 'buddypress' ); ?></p>
	</div><?php endif; ?>    <?php
} 
}
?>
